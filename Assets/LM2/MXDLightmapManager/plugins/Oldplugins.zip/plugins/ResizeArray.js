 class ResizeArray{

static function Add(key,obj)
{
var LMArray : LightmapData[]  = LightmapSettings.lightmaps;
var newarr = new Array (LMArray);
newarr[key] = obj;
 var builtinArray : LightmapData[] =newarr.ToBuiltin(LightmapData); 
LightmapSettings.lightmaps = builtinArray;
}
}