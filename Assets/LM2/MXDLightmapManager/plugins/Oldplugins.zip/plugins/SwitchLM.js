public class SwitchLM{

static function switchmaps(far,near,index,SwitchTexturesFar,SwitchTexturesNear)
{
var LMArray : LightmapData[]  = LightmapSettings.lightmaps;
var newarr = new Array (LMArray);
if (far != -1)
            newarr[index].lightmapFar = SwitchTexturesFar[far];
if (near != -1)
            newarr[index].lightmapNear = SwitchTexturesNear[near];           

var builtinArray : LightmapData[] =newarr.ToBuiltin(LightmapData); 
LightmapSettings.lightmaps = builtinArray;
}
}